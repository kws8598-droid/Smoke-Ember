import { tips } from "@/lib/tips";

export const metadata = { title: "Tips" };

export default function TipsPage() {
  return (
    <main className="page">
      <p className="kicker">Hold the line</p>
      <h1>Pit tips</h1>
      <section className="grid">
        {tips.map((tip) => (
          <article className="card" key={tip.id}>
            <p className="meta">{tip.id}</p>
            <h2>{tip.title}</h2>
            <p>{tip.body}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
