import Link from "next/link";
import { recipes } from "@/lib/recipes";

export const metadata = { title: "Recipes" };

export default function RecipesPage() {
  return (
    <main className="page">
      <p className="kicker">The book</p>
      <h1>Recipes</h1>
      <section className="grid">
        {recipes.map((recipe) => (
          <Link className="card" key={recipe.slug} href={`/recipes/${recipe.slug}`}>
            <p className="meta">
              {recipe.category} · {recipe.time}
            </p>
            <h2>{recipe.title}</h2>
            <p>{recipe.summary}</p>
          </Link>
        ))}
      </section>
    </main>
  );
}
