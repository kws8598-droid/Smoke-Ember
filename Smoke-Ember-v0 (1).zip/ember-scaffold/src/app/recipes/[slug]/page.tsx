import { notFound } from "next/navigation";
import { getRecipe, recipes } from "@/lib/recipes";

export function generateStaticParams() {
  return recipes.map((recipe) => ({ slug: recipe.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const recipe = getRecipe(params.slug);
  return { title: recipe?.title ?? "Recipe" };
}

export default function RecipePage({ params }: { params: { slug: string } }) {
  const recipe = getRecipe(params.slug);
  if (!recipe) notFound();

  return (
    <main className="page">
      <p className="kicker">
        {recipe.category} · {recipe.protein}
      </p>
      <h1>{recipe.title}</h1>
      <p className="lede">{recipe.summary}</p>
      <div className="stack">
        <article className="panel">
          <p className="meta">Yield / timing</p>
          <p>
            {recipe.yield}. {recipe.time}.
          </p>
        </article>
        <article className="panel">
          <p className="meta">Ingredients</p>
          <ul className="list">
            {recipe.ingredients.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>
        <article className="panel">
          <p className="meta">Method</p>
          <ol className="list">
            {recipe.steps.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </article>
        <article className="panel">
          <p className="meta">Do not screw this up</p>
          <ul className="list">
            {recipe.notes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </article>
      </div>
    </main>
  );
}
