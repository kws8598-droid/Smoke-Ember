export type Tip = {
  id: string;
  title: string;
  body: string;
};

export const tips: Tip[] = [
  {
    id: "fire",
    title: "Fire first, ego second",
    body: "Clean coal, clean start. Dirty fire writes itself into the bark and no mop will hide it."
  },
  {
    id: "skin",
    title: "Chicken skin is a schedule, not a vibe",
    body: "Render fat early, set color mid-cook, mop late. If you mop while the skin is still flabby you steam it and lose the bite."
  },
  {
    id: "inject",
    title: "Injection is seasoning, not a fountain",
    body: "Grid pattern, slow plunger, no balloons. If it squirts back at you, you already put enough in that hole."
  },
  {
    id: "rest",
    title: "Rest like you mean it",
    body: "Pork that does not rest turns a good cook into a dry slice. Give the butt time after probe-tender before you turn it into a box."
  },
  {
    id: "box",
    title: "The box is a photo, not a buffet",
    body: "Shine, moisture, even slices, no swamp. Judges eat with their eyes for two seconds. Make those two seconds filthy rich."
  },
  {
    id: "salt",
    title: "Salt is the only non-negotiable",
    body: "Sweet, heat, smoke — all optional compared to salt. Under-seasoned meat tastes expensive and sad."
  }
];
