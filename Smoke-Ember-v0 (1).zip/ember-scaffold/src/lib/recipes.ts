export type Recipe = {
  slug: string;
  title: string;
  category: "mop" | "injection" | "cook";
  protein: string;
  time: string;
  summary: string;
  yield: string;
  ingredients: string[];
  steps: string[];
  notes: string[];
};

export const recipes: Recipe[] = [
  {
    slug: "competition-chicken-mop",
    title: "Competition Chicken Mop",
    category: "mop",
    protein: "Chicken thighs",
    time: "10 min mix, mop last 20–30 min",
    summary:
      "Thin, glossy, sweet-heat mop for competition chicken. Builds lacquer without turning the skin to candy leather.",
    yield: "About 2 cups — enough for a full chicken box plus a little extra for shine",
    ingredients: [
      "1 cup unsweetened apple juice",
      "1/4 cup apple cider vinegar",
      "3 tbsp melted unsalted butter",
      "2 tbsp Worcestershire",
      "2 tbsp light brown sugar, packed",
      "1 tbsp yellow mustard",
      "1 tbsp honey",
      "1 tsp kosher salt",
      "1 tsp paprika",
      "1/2 tsp garlic powder",
      "1/2 tsp onion powder",
      "1/4 tsp cayenne",
      "2–3 drops liquid smoke (optional, go easy)"
    ],
    steps: [
      "Warm the apple juice just enough that the sugar dissolves. Do not boil.",
      "Whisk in vinegar, mustard, honey, Worcestershire, salt, and spices.",
      "Stream in the melted butter last so it emulsifies instead of floating as grease.",
      "Hold warm in a squeeze bottle or small saucepan at the pit.",
      "Start mopping when the thighs have color and the skin has begun to set — usually the last 20–30 minutes.",
      "Two or three light coats. You want glass, not puddles.",
      "Last coat goes on right before you pull for the box so it stays wet-look under the lights."
    ],
    notes: [
      "If the skin is already tight and shiny, skip a coat. More mop is how you get sticky, blotchy chicken.",
      "Butter breaks if the mop sits cold. Rewarm and shake before every pass.",
      "This is a finish mop, not a spritz. Do not drown the bird at hour one."
    ]
  },
  {
    slug: "pork-injection",
    title: "Pork Injection",
    category: "injection",
    protein: "Pork butt / picnic",
    time: "15 min mix, inject night before or morning of",
    summary:
      "Savory-sweet injection that keeps a butt juicy through a long smoke without tasting like a ham brine.",
    yield: "About 3 cups — enough for a 8–10 lb trimmed butt",
    ingredients: [
      "2 cups unsweetened apple juice",
      "1/2 cup pineapple juice",
      "1/4 cup melted unsalted butter",
      "3 tbsp Worcestershire",
      "2 tbsp apple cider vinegar",
      "2 tbsp light brown sugar",
      "1 tbsp kosher salt",
      "1 tsp phosphates or 1 tsp extra salt if you skip phosphates",
      "1 tsp onion powder",
      "1 tsp garlic powder",
      "1/2 tsp white pepper",
      "1/2 tsp MSG (optional, but it slaps)"
    ],
    steps: [
      "Warm juices just enough to dissolve sugar and salt. Cool to room temp before loading the injector.",
      "Whisk in Worcestershire, vinegar, spices, and butter.",
      "Strain through a fine mesh so the needle does not clog.",
      "Inject on a grid: every 1–1.5 inches, both sides, angling toward the money muscle and the fat cap seam.",
      "Stop when the roast feels heavy and a little liquid weeps from previous holes. Do not balloon it.",
      "Wrap and rest in the fridge at least 4 hours, overnight if you can.",
      "Pat dry hard before rub. Wet surface = mud instead of bark."
    ],
    notes: [
      "Phosphates help hold moisture. If you skip them, do not compensate by drowning the meat in sugar.",
      "Pineapple is for brightness, not tenderizing theater. Keep it at a quarter of the liquid.",
      "Save 1/2 cup of strained injection to mop during the stall if the bark looks thirsty — not before."
    ]
  }
];

export function getRecipe(slug: string) {
  return recipes.find((recipe) => recipe.slug === slug);
}
