import site from "@/lib/og/site.json";

export const brand = {
  name: site.name,
  shortName: site.shortName,
  tagline: site.tagline,
  description: site.description,
  colors: {
    charcoal: site.palette.charcoal,
    butcherPaper: site.palette.butcherPaper,
    ember: site.palette.ember,
    warmWood: site.palette.warmWood
  }
} as const;

export type Brand = typeof brand;
